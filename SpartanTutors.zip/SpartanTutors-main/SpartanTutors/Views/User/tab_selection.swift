//
//  tab_selection.swift
//  SpartanTutors
//
//  Created by Leo on 7/14/22.
//

import Foundation

class tab_selection:ObservableObject{
    @Published var selection = 1
}
