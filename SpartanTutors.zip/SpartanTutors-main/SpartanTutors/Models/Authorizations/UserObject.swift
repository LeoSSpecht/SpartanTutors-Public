//
//  UserObject.swift
//  SpartanTutors
//
//  Created by Leo on 6/16/22.
//

import Foundation

struct userObject {
    var isSignedIn: Bool = false
    var isNewUser: Bool = false
    var uid: String = ""
    var name: String = ""
}
